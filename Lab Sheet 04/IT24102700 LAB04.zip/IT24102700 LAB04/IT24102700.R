setwd("C:\\Users\\it24102700\\Desktop\\IT24102700 LAB04")
branch_data <- read.table("Exercise.txt", header = TRUE, sep=",")


str(branch_data)

#get the summary of data
summary(branch_data)

#boxplot for sales
boxplot(branch_data$Sales_X1, main = "Boxplot of sales", ylab = "sales")

#summAry of the five number and IQR for advertising
summary(branch_data$Advertising)
#IQR
IQR(branch_data$Advertising_X2)

#FINDING THE OUTLIERS
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 +1.5 * IQR_value
  outliers <- x[x < lower_bound |x> upper_bound]
  return(outliers)
}
#check for outliers in the "Years" variable
find_outliers(branch_data$Years)
